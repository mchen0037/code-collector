### A platform for automated code submission, execution, and debugging for upper-division computer science classes, promoting a more intuitive learning environment.

#### Dependencies

```
sudo pip install flask
```

```
sudo pip install flask-bootstrap
```

```
sudo pip install flask-wtf
```

```
sudo pip install flask-codemirror
```
